from aiogram import Router,F
from aiogram.types import Message
from database import save_plan,get_plans
router=Router(name='study')
@router.message(F.text=='📅 برنامه مطالعه')
async def plan(m:Message):
 ps=await get_plans(m.from_user.id); text='📅 <b>برنامه مطالعه</b>\n\nبرای ساخت برنامه: /plan عنوان | تاریخ | دقیقه | توضیح\n\nبرنامه‌های فعلی:\n'+('\n'.join(f'• {p["title"]} | {p["target_date"]} | {p["minutes"]} دقیقه' for p in ps[:10]) if ps else 'هنوز برنامه‌ای ثبت نشده.') ; await m.answer(text)
@router.message(F.text.startswith('/plan '))
async def make(m:Message):
 try:
  title,date,mins,*notes=m.text[6:].split('|'); await save_plan(m.from_user.id,title.strip(),date.strip(),int(mins),notes[0].strip() if notes else ''); await m.answer('✅ برنامه مطالعه ثبت شد.')
 except: await m.answer('فرمت: /plan عنوان | تاریخ | دقیقه | توضیح')
