from aiogram import Router,F
from aiogram.types import CallbackQuery,Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.state import State,StatesGroup
from aiogram.fsm.context import FSMContext
from database import chapters,lessons,get_lesson,get_questions,save_progress,save_quiz,add_weak,add_flashcard,get_weak,get_stats
router=Router(name='education')
class QuizState(StatesGroup):
    active=State()
def kb(rows):
    b=InlineKeyboardBuilder()
    for text,data in rows: b.button(text=text,callback_data=data)
    b.adjust(1); return b.as_markup()
@router.message(F.text=='📚 آموزش جامع')
async def education_menu(m:Message):
    await m.answer('📚 <b>آموزش جامع</b>\n\nدوره را انتخاب کن:',reply_markup=kb([('📚 مدیریت و بازرگانی','edu:management'),('🌍 تجارت بین‌الملل','edu:international_trade'),('🏦 بانکداری','edu:banking'),('💰 مدیریت مالی','edu:finance'),('🧾 حسابداری','edu:accounting'),('📣 بازاریابی و فروش','edu:marketing'),('📐 دروس پایه مدیریت','edu:foundations'),('🇬🇧 زبان انگلیسی','edu:english')]))
@router.callback_query(F.data.startswith('edu:'))
async def module(c:CallbackQuery):
    mid=c.data.split(':',1)[1]; ch=await chapters(mid)
    if not ch: await c.message.edit_text('⏳ این ماژول هنوز محتوای کامل قابل ارائه ندارد. ماژول‌های دارای محتوای واقعی فعلاً مدیریت و تجارت بین‌الملل هستند.'); await c.answer(); return
    rows=[]
    for x in ch: rows.append((f'📘 فصل {x["chapter_id"]}  |  {x["n"]} درس',f'ch:{mid}:{x["chapter_id"]}'))
    rows.append(('⬅️ آموزش جامع','back:edu'))
    await c.message.edit_text('📚 <b>فهرست فصل‌ها</b>',reply_markup=kb(rows)); await c.answer()
@router.callback_query(F.data.startswith('ch:'))
async def chapter(c:CallbackQuery):
    _,mid,cid=c.data.split(':',2); ls=await lessons(mid,cid); rows=[(f'📖 {x["title"]}',f'ls:{x["id"]}') for x in ls]; rows.append(('⬅️ فصل‌ها',f'edu:{mid}')); await c.message.edit_text(f'📘 <b>فصل {cid}</b>\n\nدرس را انتخاب کن:',reply_markup=kb(rows)); await c.answer()
@router.callback_query(F.data.startswith('ls:'))
async def lesson(c:CallbackQuery):
    lid=c.data.split(':',1)[1]; l=await get_lesson(lid)
    if not l: await c.answer('درس پیدا نشد',show_alert=True); return
    import json; meta=json.loads(l['metadata']); txt=f'📖 <b>{l["title"]}</b>\n\n{l["content"][:3500]}'
    if meta.get('subtopics'): txt+='\n\n<b>🔹 سرفصل‌ها</b>\n'+'\n'.join('• '+str(x) for x in meta['subtopics'][:10])
    if meta.get('specialized_tips'): txt+='\n\n<b>🎓 نکات تخصصی</b>\n'+'\n'.join('• '+str(x) for x in meta['specialized_tips'][:8])
    if meta.get('exam_tips'): txt+='\n\n<b>🎯 نکات آزمونی</b>\n'+'\n'.join('• '+str(x) for x in meta['exam_tips'][:8])
    rows=[('🧠 آزمون درس',f'quiz:{lid}'),('⭐ ثبت به‌عنوان مرور','done:'+lid)]
    if meta.get('examples'): rows.append(('💡 مثال و کاربرد','ex:'+lid))
    await c.message.edit_text(txt,reply_markup=kb(rows)); await c.answer()
@router.callback_query(F.data.startswith('ex:'))
async def examples(c:CallbackQuery):
    lid=c.data.split(':',1)[1]; l=await get_lesson(lid); import json; m=json.loads(l['metadata']); text='💡 <b>مثال‌ها و مطالعه موردی</b>\n\n'+'\n'.join('• '+str(x) for x in m.get('examples',[]))
    if m.get('case_study'): text+='\n\n<b>مطالعه موردی:</b>\n'+str(m['case_study'])
    await c.message.edit_text(text,reply_markup=kb([('🧠 شروع آزمون',f'quiz:{lid}'),('⬅️ بازگشت به درس',f'ls:{lid}') ])); await c.answer()
@router.callback_query(F.data.startswith('done:'))
async def done(c:CallbackQuery):
    lid=c.data.split(':',1)[1]; await save_progress(c.from_user.id,lid,'completed',100,0); await c.answer('پیشرفت درس ثبت شد ✅');
@router.callback_query(F.data.startswith('quiz:'))
async def start_quiz(c:CallbackQuery,state:FSMContext):
    lid=c.data.split(':',1)[1]; qs=await get_questions(lid)
    if not qs: await c.answer('برای این درس سوالی ثبت نشده.',show_alert=True); return
    await state.set_state(QuizState.active); await state.update_data(lesson_id=lid,index=0,score=0,questions=qs)
    await send_question(c.message,state)
async def send_question(message,state):
    d=await state.get_data(); i=d['index']; q=d['questions'][i]; rows=[(f'{chr(65+j)}. {o[:90]}',f'ans:{j}') for j,o in enumerate(q['options'])]; rows.append(('❌ خروج از آزمون','quizexit')); await message.edit_text(f'🧠 <b>سوال {i+1} از {len(d["questions"])}</b>\n\n{q["question"]}',reply_markup=kb(rows))
@router.callback_query(QuizState.active,F.data.startswith('ans:'))
async def answer(c:CallbackQuery,state:FSMContext):
    d=await state.get_data(); i=d['index']; q=d['questions'][i]; chosen=int(c.data.split(':')[1]); score=d['score']; correct=chosen==q['correct_index']; score+=int(correct)
    if not correct: await add_weak(c.from_user.id,q['question'][:120])
    d.update(score=score,index=i+1); await state.set_data(d)
    await c.answer('✅ درست' if correct else '❌ نادرست')
    if d['index']>=len(d['questions']):
        await save_quiz(c.from_user.id,d['lesson_id'],score,len(d['questions'])); await save_progress(c.from_user.id,d['lesson_id'],'completed',100,score/len(d['questions'])*100); await state.clear(); await c.message.edit_text(f'🏁 <b>نتیجه آزمون</b>\n\nنمره: <b>{score} از {len(d["questions"])}</b>\nدرصد: <b>{round(score/len(d["questions"])*100)}٪</b>\n\nپیشرفت درس ثبت شد.'); return
    await send_question(c.message,state)
@router.callback_query(QuizState.active,F.data=='quizexit')
async def exit_quiz(c:CallbackQuery,state:FSMContext): await state.clear(); await c.message.edit_text('آزمون متوقف شد. پیشرفت ثبت‌شده قبلی حفظ می‌شود.'); await c.answer()
@router.message(F.text=='🧠 ابزار مطالعه')
async def study_tools(m:Message):
    s=await get_stats(m.from_user.id); w=await get_weak(m.from_user.id); await m.answer(f'🧠 <b>ابزار مطالعه</b>\n\n📖 درس‌های تمام‌شده: {s["completed_lessons"]}\n📝 آزمون‌ها: {s["quizzes"]}\n📊 میانگین: {s["avg_score"]}٪\n\n⚠️ نقاط ضعف: {len(w)}',reply_markup=kb([('🧠 نقاط ضعف','weak'),('📊 آمار پیشرفت','stats')]))
@router.callback_query(F.data=='weak')
async def weak(c:CallbackQuery):
    w=await get_weak(c.from_user.id); await c.message.edit_text('⚠️ <b>نقاط ضعف</b>\n\n'+('\n'.join(f'• {x["topic"]} | خطا: {x["errors"]}' for x in w[:15]) if w else 'هنوز داده‌ای ثبت نشده.')); await c.answer()
@router.callback_query(F.data=='stats')
async def stats(c:CallbackQuery):
    s=await get_stats(c.from_user.id); await c.message.edit_text(f'📊 <b>آمار پیشرفت</b>\n\nدرس‌های تکمیل‌شده: {s["completed_lessons"]}\nتعداد آزمون‌ها: {s["quizzes"]}\nمیانگین نمره: {s["avg_score"]}٪'); await c.answer()
