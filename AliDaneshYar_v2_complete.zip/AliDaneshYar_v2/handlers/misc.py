from aiogram import Router,F
from aiogram.types import Message
from database import get_bookmarks
router=Router(name='misc')
@router.message(F.text=='⭐ ذخیره‌شده‌ها')
async def saved(m:Message):
 b=await get_bookmarks(m.from_user.id); await m.answer('⭐ <b>ذخیره‌شده‌ها</b>\n\n'+('\n'.join(f'• {x["title"]}' for x in b[:20]) if b else 'هنوز موردی ذخیره نشده است.'))
@router.message(F.text=='⚙️ تنظیمات')
async def settings(m:Message): await m.answer('⚙️ <b>تنظیمات</b>\n\n🔐 دسترسی: خصوصی\n📚 زبان آموزش: فارسی\n🔬 منابع پژوهشی: Crossref، OpenAlex، arXiv\n🔄 پایش خودکار منابع: فعال')
