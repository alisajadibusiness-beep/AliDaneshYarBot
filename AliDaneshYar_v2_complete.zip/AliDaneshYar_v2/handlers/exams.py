from aiogram import Router,F
from aiogram.types import Message
router=Router(name='exams')
@router.message(F.text=='🎯 آزمون‌های استخدامی')
async def exams(m:Message): await m.answer('🎯 <b>آزمون‌های استخدامی</b>\n\nدسته‌ها:\n• دروس عمومی\n• تخصصی مدیریت و بازرگانی\n• بانکداری\n• حسابداری\n• اقتصاد\n• زبان انگلیسی\n• ICDL\n• هوش و استعداد\n• ریاضی و آمار\n\nساختار آزمون بر اساس دفترچه هر آزمون قابل توسعه است و فهرست دروس یکسان و ثابت برای همه دستگاه‌ها فرض نمی‌شود.')
