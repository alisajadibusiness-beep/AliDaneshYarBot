from aiogram import Router,F
from aiogram.types import Message
from aiogram.filters import Command
from database import save_search,search_articles
from services.scientific_search import search_all
router=Router(name='search')
@router.message(F.text=='🔎 جستجوی هوشمند')
async def smart(m:Message): await m.answer('🔎 عبارت پژوهشی را بفرست. نمونه: مدیریت استراتژیک، بانکداری دیجیتال، هوش مصنوعی در کسب‌وکار')
@router.message(Command('search'))
async def cmd(m:Message): await do_search(m,(m.text or '').replace('/search','',1).strip())
@router.message(F.text.regexp(r'^جستجو[:：]\s*.+$'))
async def txt(m:Message): await do_search(m,(m.text or '').split(':',1)[1].strip())
async def do_search(m,q):
 if not q: await m.answer('عبارت جستجو خالی است.'); return
 await save_search(m.from_user.id,q); await m.answer('🔎 در منابع علمی جستجو می‌کنم...')
 try: results=await search_all(q,5)
 except Exception: results=[]
 if not results: results=await search_articles(q,10)
 if not results: await m.answer('نتیجه‌ای پیدا نشد.'); return
 lines=['🔬 <b>نتایج پژوهش</b>']
 for i,a in enumerate(results[:10],1): lines.append(f'\n<b>{i}. {a.get("title","")[:180]}</b>\nمنبع: {a.get("source","")}\n{a.get("published_at","")}\n{a.get("url","")}')
 await m.answer('\n'.join(lines),disable_web_page_preview=True)
