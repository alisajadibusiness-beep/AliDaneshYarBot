from aiogram import Router,F
from aiogram.types import Message
from database import save_file,get_files
from config import FILES_DIR
router=Router(name='library')
@router.message(F.text=='📄 کتابخانه شخصی')
async def library(m:Message):
 fs=await get_files(m.from_user.id); await m.answer('📄 <b>کتابخانه شخصی</b>\n\nفایل را همین‌جا ارسال کن تا ثبت شود.\n\nتعداد فایل‌های ثبت‌شده: '+str(len(fs)))
@router.message(F.document)
async def document(m:Message):
 d=m.document; path=FILES_DIR/f'{m.from_user.id}_{d.file_unique_id}_{d.file_name}'; await m.bot.download(d,path=path); await save_file(m.from_user.id,d.file_id,d.file_name,d.mime_type or '',d.file_size or 0,d.file_unique_id); await m.answer(f'✅ فایل <b>{d.file_name}</b> در کتابخانه شخصی ثبت شد.')
