from aiogram import Router,F
from aiogram.filters import CommandStart
from aiogram.types import Message
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from database import register_user
router=Router(name='start')
def menu():
 b=ReplyKeyboardBuilder(); rows=['🏠 منوی اصلی','📚 آموزش جامع','🎯 آزمون‌های استخدامی','🔬 تحقیق و مقالات','🔎 جستجوی هوشمند','📄 کتابخانه شخصی','🧠 ابزار مطالعه','📅 برنامه مطالعه','⭐ ذخیره‌شده‌ها','⚙️ تنظیمات']; [b.button(text=x) for x in rows]; b.adjust(2,2,2,2,2); return b.as_markup(resize_keyboard=True)
@router.message(CommandStart())
async def start(m:Message):
 await register_user(m.from_user.id,m.from_user.username or '',m.from_user.full_name or ''); await m.answer('🟢 <b>علی دانش‌یار</b> آماده است.\n\nپژوهش، آموزش، آزمون و مدیریت مطالعه در یک ربات شخصی.',reply_markup=menu())
@router.message(F.text=='🏠 منوی اصلی')
async def home(m:Message): await m.answer('🏠 <b>منوی اصلی</b>',reply_markup=menu())
