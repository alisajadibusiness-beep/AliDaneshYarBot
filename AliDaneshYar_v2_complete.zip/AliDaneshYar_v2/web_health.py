from aiohttp import web
async def start_server(host='0.0.0.0',port=10000):
    app=web.Application()
    async def health(r): return web.json_response({'status':'ok','service':'AliDaneshYarBot'})
    async def root(r): return web.json_response({'service':'علی دانش‌یار','status':'running'})
    app.router.add_get('/',root); app.router.add_get('/health',health)
    runner=web.AppRunner(app); await runner.setup(); await web.TCPSite(runner,host,port).start(); return runner
