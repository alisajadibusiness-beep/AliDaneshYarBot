# علی دانش‌یار | نسخه تکمیلی 2.0

ربات شخصی خصوصی برای آموزش، پژوهش، آزمون استخدامی، کتابخانه و برنامه مطالعه.

## قابلیت‌ها
- دسترسی خصوصی بر اساس `ALLOWED_USER_IDS`
- آموزش واقعی مدیریت و تجارت بین‌الملل
- فصل → درس → درسنامه → نکات تخصصی → نکات آزمونی → مثال → آزمون
- آزمون چندسؤالی با ثبت نمره
- ثبت پیشرفت و نقاط ضعف
- فلش‌کارت دیتابیس‌محور
- کتابخانه شخصی فایل‌ها
- جستجوی علمی Crossref/OpenAlex/arXiv
- ذخیره خودکار نتایج پژوهشی در SQLite
- پایش خودکار منابع هر 24 ساعت
- برنامه مطالعه
- آمار پیشرفت
- HTTP `/health` برای Render/UptimeRobot

## Render
Build: `pip install -r requirements.txt`
Start: `python bot.py`
Health Check: `/health`
Port: از `PORT` خوانده می‌شود و پیش‌فرض 10000 است.

## Environment Variables
`BOT_TOKEN`
`ALLOWED_USER_IDS`
`DATABASE_URL=sqlite+aiosqlite:///./data/bot.db`
`AUTO_UPDATE_ENABLED=true`
`AUTO_UPDATE_INTERVAL_HOURS=24`
`AUTO_UPDATE_LIMIT=8`

## تست محلی
```bash
python -m py_compile bot.py database.py config.py handlers/*.py services/*.py
python bot.py
```

## نکته ذخیره‌سازی
SQLite روی فضای محلی Render برای نسخه رایگان مناسب شروع است، اما برای پایداری بلندمدت بهتر است PostgreSQL یا Persistent Disk استفاده شود.
