from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from config import ALLOWED_USER_IDS
class PrivateAccessMiddleware(BaseMiddleware):
    async def __call__(self,handler,event,data):
        uid=getattr(getattr(event,'from_user',None),'id',None)
        if uid not in ALLOWED_USER_IDS:
            if hasattr(event,'answer'): await event.answer('🔐 این ربات خصوصی است و دسترسی شما مجاز نیست.')
            return None
        return await handler(event,data)
