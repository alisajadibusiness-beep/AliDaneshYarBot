import importlib.util, json
from pathlib import Path
from database import upsert_lesson, upsert_question
BASE=Path(__file__).resolve().parent.parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
async def initialize_content():
    imported={'management':0,'international_trade':0,'questions':0}
    mg=load('data_fixed',BASE/'data_fixed.py')
    chapters=getattr(mg,'MANAGEMENT_CHAPTERS',[])
    # data_fixed may contain compatibility trade chapters; only import real management IDs.
    for ch in chapters:
        cid=str(ch.get('id',''))
        if not cid.startswith('management_'): continue
        for l in ch.get('lessons',[]):
            lesson=dict(l); lid=str(lesson.get('id'))
            meta={k:lesson.get(k) for k in ('subtopics','specialized_tips','exam_tips','examples','case_study','keywords','review','resources') if k in lesson}
            await upsert_lesson({'id':lid,'module_id':'management','chapter_id':cid,'title':lesson.get('title',lid),'content':lesson.get('content',''),'metadata':meta}); imported['management']+=1
            for i,q in enumerate(lesson.get('quiz',[]) or []):
                await upsert_question({'id':f'management:{lid}:{i}','module_id':'management','lesson_id':lid,'question':q.get('question',''),'options':q.get('options',[]),'correct_index':q.get('correct_index',0),'explanation':q.get('explanation',''),'source':'management'})
                imported['questions']+=1
    it=load('data_international_trade_FINAL',BASE/'data_international_trade_FINAL.py')
    for ch in it.get_chapters():
        cid=ch['id']
        for l in it.get_lessons(cid):
            lid=l['id']; meta={k:l.get(k) for k in ('subtopics','specialized_tips','exam_tips','examples','case_study','keywords','review','resources') if k in l}
            await upsert_lesson({'id':lid,'module_id':'international_trade','chapter_id':cid,'title':l.get('title',lid),'content':l.get('content',''),'metadata':meta}); imported['international_trade']+=1
            for i,q in enumerate(it.get_quiz_questions(cid,lid)):
                opts=q.get('options',[]); opts=[x.get('text',str(x)) if isinstance(x,dict) else str(x) for x in opts]
                ans=q.get('answer',q.get('correct_answer','A')); idx='ABCD'.find(str(ans))
                if idx<0: idx=0
                await upsert_question({'id':f'international_trade:{lid}:{i}','module_id':'international_trade','lesson_id':lid,'question':q.get('question',''),'options':opts,'correct_index':idx,'explanation':q.get('explanation',''),'source':'international_trade'}); imported['questions']+=1
    return imported
