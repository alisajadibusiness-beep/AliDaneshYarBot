import asyncio, logging
from config import AUTO_UPDATE_ENABLED,AUTO_UPDATE_INTERVAL_HOURS,AUTO_UPDATE_LIMIT,WATCH_TOPICS
from services.scientific_search import search_all
log=logging.getLogger(__name__)
async def run_update():
    total=0
    for _,(_,queries) in WATCH_TOPICS.items():
        for q in queries[:2]:
            try: total+=len(await search_all(q,AUTO_UPDATE_LIMIT))
            except Exception: log.exception('update failed: %s',q)
    log.info('Auto update completed: %s resources processed',total); return total
async def auto_update_loop(bot=None):
    if not AUTO_UPDATE_ENABLED: return
    await asyncio.sleep(30)
    while True:
        try: await run_update()
        except asyncio.CancelledError: raise
        except Exception: log.exception('auto updater error')
        await asyncio.sleep(AUTO_UPDATE_INTERVAL_HOURS*3600)
