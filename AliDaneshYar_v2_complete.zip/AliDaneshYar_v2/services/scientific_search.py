import aiohttp, feedparser, urllib.parse
from datetime import datetime
from config import CROSSREF_API_URL,OPENALEX_API_URL,ARXIV_API_URL
from database import save_article
async def _json(url,params=None):
    timeout=aiohttp.ClientTimeout(total=20)
    async with aiohttp.ClientSession(timeout=timeout,headers={'User-Agent':'AliDaneshYarBot/2.0'}) as s:
        async with s.get(url,params=params) as r:
            r.raise_for_status(); return await r.json()
async def crossref(query,limit=5):
    data=await _json(CROSSREF_API_URL,{'query.bibliographic':query,'rows':limit,'select':'DOI,title,author,published,URL,abstract'}); out=[]
    for x in data.get('message',{}).get('items',[]):
        title=(x.get('title') or [''])[0]; doi=x.get('DOI',''); out.append({'source':'Crossref','external_id':doi or x.get('URL',''),'title':title,'authors':', '.join(a.get('given','')+' '+a.get('family','') for a in x.get('author',[])),'published_at':str(x.get('published',{}).get('date-parts',[['']])[0][0]),'abstract':x.get('abstract',''),'url':x.get('URL',''),'doi':doi,'topic':query})
    return out
async def openalex(query,limit=5):
    data=await _json(OPENALEX_API_URL,{'search':query,'per-page':limit,'mailto':'research@example.com'}); out=[]
    for x in data.get('results',[]): out.append({'source':'OpenAlex','external_id':x.get('id',''),'title':x.get('display_name',''),'authors':', '.join((a.get('author') or {}).get('display_name','') for a in x.get('authorships',[])[:6]),'published_at':str(x.get('publication_year','')),'abstract':'','url':x.get('doi') or x.get('primary_location',{}).get('landing_page_url',''),'doi':x.get('doi',''),'oa_url':(x.get('open_access') or {}).get('oa_url','') or '','topic':query})
    return out
async def arxiv(query,limit=5):
    url=ARXIV_API_URL+'?search_query=all:'+urllib.parse.quote(query)+'&start=0&max_results='+str(limit)+'&sortBy=submittedDate&sortOrder=descending'
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20),headers={'User-Agent':'AliDaneshYarBot/2.0'}) as s:
        async with s.get(url) as r: text=await r.text()
    feed=feedparser.parse(text); out=[]
    for e in feed.entries: out.append({'source':'arXiv','external_id':e.get('id',''),'title':e.get('title','').strip(),'authors':', '.join(a.name for a in e.get('authors',[])),'published_at':e.get('published',''),'abstract':e.get('summary','').strip(),'url':e.get('link',''),'doi':'','oa_url':e.get('link',''),'topic':query})
    return out
async def search_all(query,limit=5):
    results=[]
    for fn in (crossref,openalex,arxiv):
        try: results.extend(await fn(query,limit))
        except Exception: pass
    for a in results: await save_article(a)
    return results
