import os
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
BASE_DIR=Path(__file__).resolve().parent
DATA_DIR=BASE_DIR/'data'; DATA_DIR.mkdir(exist_ok=True)
FILES_DIR=DATA_DIR/'files'; FILES_DIR.mkdir(exist_ok=True)
PDF_DIR=DATA_DIR/'pdfs'; PDF_DIR.mkdir(exist_ok=True)
BOT_TOKEN=os.getenv('BOT_TOKEN','').strip()
def _ids():
    out=set()
    for x in os.getenv('ALLOWED_USER_IDS','').split(','):
        try: out.add(int(x.strip()))
        except: pass
    return out
ALLOWED_USER_IDS=_ids()
DATABASE_URL=os.getenv('DATABASE_URL',f'sqlite+aiosqlite:///{DATA_DIR / "bot.db"}')
PORT=int(os.getenv('PORT','10000') or 10000)
HOST='0.0.0.0'
AUTO_UPDATE_ENABLED=os.getenv('AUTO_UPDATE_ENABLED','true').lower() in {'1','true','yes','on'}
AUTO_UPDATE_INTERVAL_HOURS=max(1,int(os.getenv('AUTO_UPDATE_INTERVAL_HOURS','24') or 24))
AUTO_UPDATE_LIMIT=max(1,int(os.getenv('AUTO_UPDATE_LIMIT','8') or 8))
BOT_NAME='علی دانش‌یار'
CROSSREF_API_URL='https://api.crossref.org/works'
OPENALEX_API_URL='https://api.openalex.org/works'
ARXIV_API_URL='https://export.arxiv.org/api/query'
WATCH_TOPICS={
 'management':('مدیریت و بازرگانی',['business management','strategic management','organizational behavior']),
 'banking':('بانکداری',['banking','digital banking','bank risk']),
 'finance':('مدیریت مالی',['corporate finance','financial management','investment']),
 'accounting':('حسابداری',['accounting','financial accounting','management accounting']),
 'marketing':('بازاریابی و فروش',['marketing','digital marketing','sales management']),
 'international_business':('تجارت بین‌الملل',['international business','international trade','global business']),
 'economics':('اقتصاد',['economics','microeconomics','macroeconomics']),
 'artificial_intelligence':('هوش مصنوعی در کسب‌وکار',['AI business','generative AI business','agentic AI business']),
 'fintech':('فین‌تک',['fintech','digital finance','financial innovation']),
}
EDUCATIONAL_MODULES={
 'management':'📚 مدیریت و بازرگانی','banking':'🏦 بانکداری','finance':'💰 مدیریت مالی','accounting':'🧾 حسابداری','marketing':'📣 بازاریابی و فروش','international_trade':'🌍 تجارت بین‌الملل','foundations':'📐 دروس پایه مدیریت','english':'🇬🇧 زبان انگلیسی از صفر تا پیشرفته'}
EMPLOYMENT_MODULES={'general':'دروس عمومی','management':'تخصصی مدیریت','business_management':'مدیریت بازرگانی','public_management':'مدیریت دولتی','accounting':'حسابداری','economics':'اقتصاد','banking':'بانکداری','english':'زبان انگلیسی','icdl':'ICDL و فناوری اطلاعات','aptitude':'هوش و استعداد','mathematics':'ریاضی و آمار'}
def validate_config():
    if not BOT_TOKEN: raise RuntimeError('BOT_TOKEN تنظیم نشده است.')
    if not ALLOWED_USER_IDS: raise RuntimeError('ALLOWED_USER_IDS تنظیم نشده است.')
