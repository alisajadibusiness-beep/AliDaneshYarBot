from __future__ import annotations
import json, re
from datetime import datetime, timezone
from contextlib import asynccontextmanager
import aiosqlite
from config import DATA_DIR
DB_PATH=DATA_DIR/'bot.db'
@asynccontextmanager
async def db():
    conn=await aiosqlite.connect(DB_PATH)
    conn.row_factory=aiosqlite.Row
    await conn.execute('PRAGMA foreign_keys=ON')
    try: yield conn
    finally: await conn.close()
async def init_database():
    async with db() as c:
        await c.executescript('''
CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, username TEXT, full_name TEXT, created_at TEXT, last_seen TEXT);
CREATE TABLE IF NOT EXISTS modules(id TEXT PRIMARY KEY,title TEXT,description TEXT,category TEXT DEFAULT 'education',is_active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS lessons(id TEXT PRIMARY KEY,module_id TEXT,chapter_id TEXT,title TEXT,content TEXT,metadata TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS questions(id TEXT PRIMARY KEY,module_id TEXT,lesson_id TEXT,question TEXT,options TEXT,correct_index INTEGER,explanation TEXT,source TEXT DEFAULT 'education');
CREATE TABLE IF NOT EXISTS progress(user_id INTEGER,lesson_id TEXT,status TEXT DEFAULT 'started',percent INTEGER DEFAULT 0,score REAL DEFAULT 0,updated_at TEXT,PRIMARY KEY(user_id,lesson_id));
CREATE TABLE IF NOT EXISTS quiz_results(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,lesson_id TEXT,score INTEGER,total INTEGER,created_at TEXT);
CREATE TABLE IF NOT EXISTS flashcards(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,lesson_id TEXT,front TEXT,back TEXT,ease REAL DEFAULT 2.5,due_at TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,item_type TEXT,item_id TEXT,title TEXT,content TEXT,created_at TEXT,UNIQUE(user_id,item_type,item_id));
CREATE TABLE IF NOT EXISTS articles(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT,external_id TEXT,title TEXT,authors TEXT,published_at TEXT,abstract TEXT,url TEXT,doi TEXT,oa_url TEXT,topic TEXT,score REAL DEFAULT 0,created_at TEXT,UNIQUE(source,external_id));
CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,file_id TEXT,file_name TEXT,mime_type TEXT,file_size INTEGER,telegram_unique_id TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS study_plans(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,title TEXT,target_date TEXT,minutes INTEGER,notes TEXT,status TEXT DEFAULT 'active',created_at TEXT);
CREATE TABLE IF NOT EXISTS settings(user_id INTEGER,key TEXT,value TEXT,PRIMARY KEY(user_id,key));
CREATE TABLE IF NOT EXISTS search_history(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,query TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS weak_topics(user_id INTEGER,topic TEXT,errors INTEGER DEFAULT 0,last_seen TEXT,PRIMARY KEY(user_id,topic));
'''); await c.commit()
async def register_user(uid,username='',full_name=''):
    now=datetime.now(timezone.utc).isoformat()
    async with db() as c:
        await c.execute('INSERT INTO users VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,full_name=excluded.full_name,last_seen=excluded.last_seen',(uid,username,full_name,now,now)); await c.commit()
async def seed_modules(mods):
    async with db() as c:
        for m in mods: await c.execute('INSERT INTO modules(id,title,description,category,is_active) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,description=excluded.description,category=excluded.category,is_active=excluded.is_active',(m['id'],m['title'],m.get('description',''),m.get('category','education'),m.get('is_active',1)))
        await c.commit()
async def get_modules(category=None):
    async with db() as c:
        q='SELECT * FROM modules WHERE is_active=1'; args=[]
        if category: q+=' AND category=?'; args.append(category)
        q+=' ORDER BY category,id'; return [dict(r) for r in await (await c.execute(q,args)).fetchall()]
async def upsert_lesson(lesson):
    async with db() as c:
        await c.execute('INSERT INTO lessons(id,module_id,chapter_id,title,content,metadata) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET module_id=excluded.module_id,chapter_id=excluded.chapter_id,title=excluded.title,content=excluded.content,metadata=excluded.metadata',(lesson['id'],lesson['module_id'],lesson.get('chapter_id',''),lesson['title'],lesson.get('content',''),json.dumps(lesson.get('metadata',{}),ensure_ascii=False))); await c.commit()
async def upsert_question(q):
    async with db() as c:
        await c.execute('INSERT OR IGNORE INTO questions(id,module_id,lesson_id,question,options,correct_index,explanation,source) VALUES(?,?,?,?,?,?,?,?)',(q['id'],q['module_id'],q['lesson_id'],q['question'],json.dumps(q['options'],ensure_ascii=False),q['correct_index'],q.get('explanation',''),q.get('source','education'))); await c.commit()
async def chapters(module_id):
    async with db() as c:
        rows=await (await c.execute('SELECT chapter_id,COUNT(*) n FROM lessons WHERE module_id=? GROUP BY chapter_id ORDER BY chapter_id',(module_id,))).fetchall(); return [dict(r) for r in rows]
async def lessons(module_id,chapter_id):
    async with db() as c:
        return [dict(r) for r in await (await c.execute('SELECT * FROM lessons WHERE module_id=? AND chapter_id=? ORDER BY id',(module_id,chapter_id))).fetchall()]
async def get_lesson(lesson_id):
    async with db() as c:
        r=await (await c.execute('SELECT * FROM lessons WHERE id=?',(lesson_id,))).fetchone(); return dict(r) if r else None
async def get_questions(lesson_id):
    async with db() as c:
        rows=await (await c.execute('SELECT * FROM questions WHERE lesson_id=? ORDER BY id',(lesson_id,))).fetchall()
        out=[]
        for r in rows:
            x=dict(r); x['options']=json.loads(x['options']); out.append(x)
        return out
async def save_progress(uid,lesson_id,status='completed',percent=100,score=0):
    async with db() as c:
        await c.execute('INSERT INTO progress VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET status=excluded.status,percent=excluded.percent,score=excluded.score,updated_at=excluded.updated_at',(uid,lesson_id,status,percent,score,datetime.now(timezone.utc).isoformat())); await c.commit()
async def save_quiz(uid,lesson_id,score,total):
    async with db() as c: await c.execute('INSERT INTO quiz_results(user_id,lesson_id,score,total,created_at) VALUES(?,?,?,?,?)',(uid,lesson_id,score,total,datetime.now(timezone.utc).isoformat())); await c.commit()
async def add_weak(uid,topic):
    async with db() as c: await c.execute('INSERT INTO weak_topics(user_id,topic,errors,last_seen) VALUES(?,?,1,?) ON CONFLICT(user_id,topic) DO UPDATE SET errors=errors+1,last_seen=excluded.last_seen',(uid,topic,datetime.now(timezone.utc).isoformat())); await c.commit()
async def get_weak(uid):
    async with db() as c: return [dict(r) for r in await (await c.execute('SELECT * FROM weak_topics WHERE user_id=? ORDER BY errors DESC',(uid,))).fetchall()]
async def add_flashcard(uid,lesson_id,front,back):
    async with db() as c: await c.execute('INSERT INTO flashcards(user_id,lesson_id,front,back,due_at,created_at) VALUES(?,?,?,?,?,?)',(uid,lesson_id,front,back,datetime.now(timezone.utc).isoformat(),datetime.now(timezone.utc).isoformat())); await c.commit()
async def get_flashcards(uid,limit=10):
    async with db() as c: return [dict(r) for r in await (await c.execute('SELECT * FROM flashcards WHERE user_id=? ORDER BY id DESC LIMIT ?',(uid,limit))).fetchall()]
async def save_bookmark(uid,item_type,item_id,title,content):
    async with db() as c: await c.execute('INSERT OR IGNORE INTO bookmarks(user_id,item_type,item_id,title,content,created_at) VALUES(?,?,?,?,?,?)',(uid,item_type,item_id,title,content,datetime.now(timezone.utc).isoformat())); await c.commit()
async def get_bookmarks(uid):
    async with db() as c: return [dict(r) for r in await (await c.execute('SELECT * FROM bookmarks WHERE user_id=? ORDER BY id DESC',(uid,))).fetchall()]
async def save_article(a):
    async with db() as c: await c.execute('INSERT OR IGNORE INTO articles(source,external_id,title,authors,published_at,abstract,url,doi,oa_url,topic,score,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(a.get('source',''),a.get('external_id',''),a.get('title',''),a.get('authors',''),a.get('published_at',''),a.get('abstract',''),a.get('url',''),a.get('doi',''),a.get('oa_url',''),a.get('topic',''),a.get('score',0),datetime.now(timezone.utc).isoformat())); await c.commit()
async def search_articles(q='',limit=10):
    async with db() as c:
        like=f'%{q}%'; rows=await (await c.execute('SELECT * FROM articles WHERE title LIKE ? OR abstract LIKE ? OR topic LIKE ? ORDER BY published_at DESC LIMIT ?',(like,like,like,limit))).fetchall(); return [dict(r) for r in rows]
async def get_stats(uid):
    async with db() as c:
        a=await (await c.execute('SELECT COUNT(*) n FROM progress WHERE user_id=? AND status="completed"',(uid,))).fetchone(); b=await (await c.execute('SELECT COUNT(*) n FROM quiz_results WHERE user_id=?',(uid,))).fetchone(); d=await (await c.execute('SELECT AVG(CASE WHEN total>0 THEN 100.0*score/total ELSE 0 END) x FROM quiz_results WHERE user_id=?',(uid,))).fetchone(); return {'completed_lessons':a['n'],'quizzes':b['n'],'avg_score':round(d['x'] or 0,1)}
async def save_plan(uid,title,target_date,minutes,notes=''):
    async with db() as c: await c.execute('INSERT INTO study_plans(user_id,title,target_date,minutes,notes,created_at) VALUES(?,?,?,?,?,?)',(uid,title,target_date,minutes,notes,datetime.now(timezone.utc).isoformat())); await c.commit()
async def get_plans(uid):
    async with db() as c: return [dict(r) for r in await (await c.execute('SELECT * FROM study_plans WHERE user_id=? ORDER BY id DESC',(uid,))).fetchall()]
async def set_setting(uid,key,value):
    async with db() as c: await c.execute('INSERT INTO settings VALUES(?,?,?) ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value',(uid,key,str(value))); await c.commit()
async def get_setting(uid,key,default=None):
    async with db() as c:
        r=await (await c.execute('SELECT value FROM settings WHERE user_id=? AND key=?',(uid,key))).fetchone(); return r['value'] if r else default
async def save_search(uid,q):
    async with db() as c: await c.execute('INSERT INTO search_history(user_id,query,created_at) VALUES(?,?,?)',(uid,q,datetime.now(timezone.utc).isoformat())); await c.commit()
async def save_file(uid,file_id,name,mime,size,unique=''):
    async with db() as c: await c.execute('INSERT INTO files(user_id,file_id,file_name,mime_type,file_size,telegram_unique_id,created_at) VALUES(?,?,?,?,?,?,?)',(uid,file_id,name,mime,size,unique,datetime.now(timezone.utc).isoformat())); await c.commit()
async def get_files(uid):
    async with db() as c: return [dict(r) for r in await (await c.execute('SELECT * FROM files WHERE user_id=? ORDER BY id DESC',(uid,))).fetchall()]
async def database_health_check():
    async with db() as c: await c.execute('SELECT 1'); return {'status':'ok','path':str(DB_PATH)}
