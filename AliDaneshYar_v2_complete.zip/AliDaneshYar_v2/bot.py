from __future__ import annotations
import asyncio,logging,sys
from aiogram import Bot,Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from config import *
from database import init_database,seed_modules,database_health_check
from services.content_initializer import initialize_content
from services.auto_updater import auto_update_loop
from handlers.start import router as start_router
from handlers.education import router as education_router
from handlers.search import router as search_router
from handlers.exams import router as exams_router
from handlers.library import router as library_router
from handlers.study import router as study_router
from handlers.misc import router as misc_router
from utils.access import PrivateAccessMiddleware
from web_health import start_server
logging.basicConfig(level=getattr(logging,os.getenv('LOG_LEVEL','INFO').upper()),format='%(asctime)s | %(levelname)s | %(name)s | %(message)s',handlers=[logging.StreamHandler(sys.stdout)])
log=logging.getLogger('AliDaneshYar')
async def main():
 validate_config(); await init_database()
 mods=[]
 for k,v in EDUCATIONAL_MODULES.items(): mods.append({'id':k,'title':v,'description':f'دوره جامع {v}','category':'education'})
 for k,v in EMPLOYMENT_MODULES.items(): mods.append({'id':'exam_'+k,'title':v,'description':f'آمادگی آزمون: {v}','category':'employment'})
 await seed_modules(mods)
 result=await initialize_content(); log.info('content: %s',result); log.info('db: %s',await database_health_check())
 bot=Bot(BOT_TOKEN,default=DefaultBotProperties(parse_mode=ParseMode.HTML)); dp=Dispatcher(storage=MemoryStorage())
 for r in (education_router,start_router,search_router,exams_router,library_router,study_router,misc_router): r.message.middleware(PrivateAccessMiddleware()); r.callback_query.middleware(PrivateAccessMiddleware()); dp.include_router(r)
 runner=await start_server(HOST,PORT)
 updater=asyncio.create_task(auto_update_loop(bot)) if AUTO_UPDATE_ENABLED else None
 try:
  for uid in ALLOWED_USER_IDS:
   try: await bot.send_message(uid,'🟢 <b>نسخه تکمیلی علی دانش‌یار فعال شد.</b>\n\nآموزش واقعی، آزمون چندسؤالی، پیشرفت، کتابخانه، جستجوی علمی و پایش خودکار منابع فعال است.')
   except Exception: log.exception('startup msg failed')
  await bot.delete_webhook(drop_pending_updates=True); await dp.start_polling(bot,allowed_updates=dp.resolve_used_update_types())
 finally:
  if updater: updater.cancel();
  if updater:
   try: await updater
   except asyncio.CancelledError: pass
  await runner.cleanup(); await bot.session.close()
if __name__=='__main__': asyncio.run(main())
